package org.pg.eti.kask.ont.editor.panels;

import java.awt.Color;

import javax.swing.JPanel;

public class PropertiesPanel extends JPanel {

	private static final long serialVersionUID = 71226182059817663L;

	public PropertiesPanel(){
		this.setBackground(Color.GREEN);
	}
}
