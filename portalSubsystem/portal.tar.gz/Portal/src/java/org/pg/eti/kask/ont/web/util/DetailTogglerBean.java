package org.pg.eti.kask.ont.web.util;

import org.apache.myfaces.component.html.ext.HtmlDataTable;

public class DetailTogglerBean extends HtmlDataTable {

}
